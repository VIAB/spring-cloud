package com.luxoft.training.spring.cloud;

public class OAuth2Configuration {
}