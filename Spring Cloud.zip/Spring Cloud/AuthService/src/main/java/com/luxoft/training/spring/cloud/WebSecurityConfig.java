package com.luxoft.training.spring.cloud;

class WebSecurityConfig {
}