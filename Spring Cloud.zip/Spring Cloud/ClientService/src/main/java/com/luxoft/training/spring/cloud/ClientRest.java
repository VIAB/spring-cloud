package com.luxoft.training.spring.cloud;

public class ClientRest {
}
