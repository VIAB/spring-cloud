package com.luxoft.training.spring.cloud;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.stream.aggregate.AggregateApplicationBuilder;

public class Aggregator {
}
