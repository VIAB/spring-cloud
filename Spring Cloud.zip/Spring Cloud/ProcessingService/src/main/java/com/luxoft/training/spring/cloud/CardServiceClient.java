package com.luxoft.training.spring.cloud;

public interface CardServiceClient {
}
